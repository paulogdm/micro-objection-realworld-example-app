# micro-objection-realworld-example-app
Real World Example using Zeit's Micro and Vincit's Objection
